package com.zensar.quiz;

public interface UserDAO {

		public void userMenu();
		public void listSubject();
		public void selectSubject();
}
