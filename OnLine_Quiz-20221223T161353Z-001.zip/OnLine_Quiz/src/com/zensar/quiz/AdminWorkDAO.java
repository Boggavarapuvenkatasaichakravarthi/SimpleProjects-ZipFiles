package com.zensar.quiz;

public interface AdminWorkDAO {

	public void addQuestion(String subject);

	public void showLogs();

	public void displayMenu();

	public String selectSubject();

}
