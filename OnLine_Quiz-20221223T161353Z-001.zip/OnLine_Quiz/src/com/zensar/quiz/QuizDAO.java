package com.zensar.quiz;

public interface QuizDAO {

	// Method Declaration
	public void start(String subject);

	public String selectSubject();

	public void result();
}
